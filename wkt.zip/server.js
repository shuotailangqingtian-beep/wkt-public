"use strict";

const express = require("express");
const path = require("path");
const compression = require("compression");
const cors = require("cors");
const cookieParser = require("cookie-parser");

const serverYt = require("./server/youtube.js");

const app = express();
let client;

// ===== 基本設定 =====
app.use(compression());
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.set("trust proxy", 1);
app.use(cookieParser());

// ===== ログイン制御 =====
app.use((req, res, next) => {
  if (
    req.cookies.loginok !== "ok" &&
    !req.path.includes("login") &&
    !req.path.includes("back")
  ) {
    return res.redirect("/login");
  }
  next();
});

// ===== ルーティング =====
app.get("/", (req, res) => {
  if (req.query.r === "y") {
    res.render("home/index");
  } else {
    res.redirect("/wkt");
  }
});

app.get("/app", (req, res) => {
  res.render("app/list");
});

app.use("/wkt", require("./routes/wakametube"));
app.use("/game", require("./routes/game"));
app.use("/tools", require("./routes/tools"));
app.use("/pp", require("./routes/proxy"));
app.use("/wakams", require("./routes/music"));
app.use("/blog", require("./routes/blog"));
app.use("/sandbox", require("./routes/sandbox"));

app.get("/login", (req, res) => {
  res.render("home/login");
});

app.get("/watch", (req, res) => {
  const videoId = req.query.v;
  if (videoId) {
    res.redirect(`/wkt/watch/${videoId}`);
  } else {
    res.redirect(`/wkt/trend`);
  }
});

app.get("/channel/:id", (req, res) => {
  res.redirect(`/wkt/c/${req.params.id}`);
});

app.get("/hashtag/:des", (req, res) => {
  res.redirect(`/wkt/s?q=${req.params.des}`);
});

// ===== 404 =====
app.use((req, res) => {
  res.status(404).render("error.ejs", {
    title: "404 Not found",
    content: "そのページは存在しません。",
  });
});

// ===== YouTube 初期化（ESM対応）=====
async function initInnerTube() {
  try {
    const { Innertube } = await import("youtubei.js");

    client = await Innertube.create({
      lang: "ja",
      location: "JP",
    });

    serverYt.setClient(client);

    const PORT = process.env.PORT || 3000;

    const listener = app.listen(PORT, "0.0.0.0", () => {
      console.log("✅ wakametube ready on port", PORT);
    });

    listener.on("error", (err) => {
      if (err.code === "EADDRINUSE") {
        console.error("❌ Port already in use. Stop other servers.");
        process.exit(1);
      }
    });
  } catch (e) {
    console.error("❌ InnerTube init failed:", e);
    setTimeout(initInnerTube, 10000);
  }
}

process.on("unhandledRejection", console.error);
initInnerTube();
